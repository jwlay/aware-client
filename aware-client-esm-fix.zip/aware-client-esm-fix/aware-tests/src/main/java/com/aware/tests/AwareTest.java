package com.aware.tests;

import android.content.Context;

public interface AwareTest {
    void test(Context context);
}
